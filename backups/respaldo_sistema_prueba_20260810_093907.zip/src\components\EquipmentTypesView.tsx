'use client';

import React, { useState, useEffect } from 'react';
import {
  Layers,
  Plus,
  Edit2,
  Trash2,
  Settings,
  PlusCircle,
  CheckCircle2,
  Sliders,
  Tag,
  Cpu,
  Check,
  Search,
  Filter,
} from 'lucide-react';
import { DynamicAttributeDef } from '@/types';

interface EquipmentTypesViewProps {
  userRole: string;
}

export default function EquipmentTypesView({ userRole }: EquipmentTypesViewProps) {
  const [activeTab, setActiveTab] = useState<'types' | 'brands' | 'models'>('types');
  const [types, setTypes] = useState<any[]>([]);
  const [brands, setBrands] = useState<any[]>([]);
  const [models, setModels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & dropdown filters inside tabs
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrandFilter, setSelectedBrandFilter] = useState('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState('');

  // Equipment Type Modal State
  const [isTypeModalOpen, setIsTypeModalOpen] = useState(false);
  const [editingType, setEditingType] = useState<any>(null);
  const [typeName, setTypeName] = useState('');
  const [typeDescription, setTypeDescription] = useState('');
  const [attributes, setAttributes] = useState<DynamicAttributeDef[]>([]);
  const [selectedBrandIds, setSelectedBrandIds] = useState<string[]>([]);

  const [attrKey, setAttrKey] = useState('');
  const [attrLabel, setAttrLabel] = useState('');
  const [attrType, setAttrType] = useState<'text' | 'number' | 'select' | 'boolean'>('text');

  // Brand Modal State
  const [isBrandModalOpen, setIsBrandModalOpen] = useState(false);
  const [editingBrand, setEditingBrand] = useState<any>(null);
  const [brandName, setBrandName] = useState('');

  // Model Modal State
  const [isModelModalOpen, setIsModelModalOpen] = useState(false);
  const [editingModel, setEditingModel] = useState<any>(null);
  const [modelName, setModelName] = useState('');
  const [modelBrandId, setModelBrandId] = useState('');
  const [modelTypeId, setModelTypeId] = useState('');
  const [modelRam, setModelRam] = useState('');
  const [modelProcessor, setModelProcessor] = useState('');
  const [modelStorage, setModelStorage] = useState('');
  const [modelInkType, setModelInkType] = useState('');
  const [modelNetworkPort, setModelNetworkPort] = useState('');
  const [modelScreenSize, setModelScreenSize] = useState('');
  const [modelLumens, setModelLumens] = useState('');
  const [modelResolution, setModelResolution] = useState('');

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [resT, resB, resM] = await Promise.all([
        fetch('/api/equipment-types'),
        fetch('/api/brands'),
        fetch('/api/models'),
      ]);
      const dataT = await resT.json();
      const dataB = await resB.json();
      const dataM = await resM.json();

      setTypes(Array.isArray(dataT) ? dataT : []);
      setBrands(Array.isArray(dataB) ? dataB : []);
      setModels(Array.isArray(dataM) ? dataM : []);
    } catch (err) {
      console.error('Error loading catalog data:', err);
    } finally {
      setLoading(false);
    }
  };

  // --- TYPE HANDLERS ---
  const handleOpenTypeModal = (type?: any) => {
    setError('');
    if (type) {
      setEditingType(type);
      setTypeName(type.name);
      setTypeDescription(type.description || '');
      try {
        setAttributes(JSON.parse(type.dynamic_attributes || '[]'));
      } catch (e) {
        setAttributes([]);
      }
      try {
        setSelectedBrandIds(JSON.parse(type.associated_brands || '[]'));
      } catch (e) {
        setSelectedBrandIds([]);
      }
    } else {
      setEditingType(null);
      setTypeName('');
      setTypeDescription('');
      setAttributes([]);
      setSelectedBrandIds([]);
    }
    setAttrKey('');
    setAttrLabel('');
    setAttrType('text');
    setIsTypeModalOpen(true);
  };

  const toggleBrandAssociation = (brandId: string) => {
    if (selectedBrandIds.includes(brandId)) {
      setSelectedBrandIds(selectedBrandIds.filter((bId) => bId !== brandId));
    } else {
      setSelectedBrandIds([...selectedBrandIds, brandId]);
    }
  };

  const handleAddAttribute = () => {
    if (!attrKey || !attrLabel) return;
    const cleanKey = attrKey.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    if (attributes.some((a) => a.key === cleanKey)) {
      alert('Ya existe un atributo con esta clave');
      return;
    }

    setAttributes([...attributes, { key: cleanKey, label: attrLabel, type: attrType }]);
    setAttrKey('');
    setAttrLabel('');
    setAttrType('text');
  };

  const handleRemoveAttribute = (key: string) => {
    setAttributes(attributes.filter((a) => a.key !== key));
  };

  const handleSaveType = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const url = editingType ? `/api/equipment-types/${editingType.id}` : '/api/equipment-types';
      const method = editingType ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: typeName,
          description: typeDescription,
          dynamic_attributes: JSON.stringify(attributes),
          associated_brands: JSON.stringify(selectedBrandIds),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al guardar tipo de equipo');

      setSuccess(`Tipo de equipo ${editingType ? 'actualizado' : 'creado'} correctamente.`);
      setIsTypeModalOpen(false);
      loadAllData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteType = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar este tipo de equipo?')) return;
    try {
      const res = await fetch(`/api/equipment-types/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al eliminar');
      loadAllData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // --- BRAND HANDLERS ---
  const handleOpenBrandModal = (brand?: any) => {
    setError('');
    if (brand) {
      setEditingBrand(brand);
      setBrandName(brand.name);
    } else {
      setEditingBrand(null);
      setBrandName('');
    }
    setIsBrandModalOpen(true);
  };

  const handleSaveBrand = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const url = editingBrand ? `/api/brands/${editingBrand.id}` : '/api/brands';
      const method = editingBrand ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: brandName }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al guardar marca');

      setSuccess(`Marca ${editingBrand ? 'actualizada' : 'creada'} correctamente.`);
      setIsBrandModalOpen(false);
      loadAllData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteBrand = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar esta marca?')) return;
    try {
      const res = await fetch(`/api/brands/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al eliminar');
      loadAllData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // --- MODEL HANDLERS ---
  const handleOpenModelModal = (model?: any) => {
    setError('');
    if (model) {
      setEditingModel(model);
      setModelName(model.name);
      setModelBrandId(model.brandId);
      setModelTypeId(model.typeId || '');
      setModelRam(model.ram || '');
      setModelProcessor(model.processor || '');
      setModelStorage(model.storage || '');

      let parsedSpecs: any = {};
      try {
        parsedSpecs = JSON.parse(model.specs || '{}');
      } catch (e) {}

      setModelInkType(parsedSpecs.ink_type || '');
      setModelNetworkPort(parsedSpecs.network_port || '');
      setModelScreenSize(parsedSpecs.screen_size || '');
      setModelLumens(parsedSpecs.lumens || '');
      setModelResolution(parsedSpecs.resolution || '');
      if (parsedSpecs.ram && !model.ram) setModelRam(parsedSpecs.ram);
      if (parsedSpecs.processor && !model.processor) setModelProcessor(parsedSpecs.processor);
      if (parsedSpecs.storage && !model.storage) setModelStorage(parsedSpecs.storage);
    } else {
      setEditingModel(null);
      setModelName('');
      setModelBrandId(selectedBrandFilter || brands[0]?.id || '');
      setModelTypeId(selectedTypeFilter || types[0]?.id || '');
      setModelRam('');
      setModelProcessor('');
      setModelStorage('');
      setModelInkType('');
      setModelNetworkPort('');
      setModelScreenSize('');
      setModelLumens('');
      setModelResolution('');
    }
    setIsModelModalOpen(true);
  };

  const handleSaveModel = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const url = editingModel ? `/api/models/${editingModel.id}` : '/api/models';
      const method = editingModel ? 'PUT' : 'POST';

      const specsObj = {
        ram: modelRam,
        processor: modelProcessor,
        storage: modelStorage,
        ink_type: modelInkType,
        network_port: modelNetworkPort,
        screen_size: modelScreenSize,
        lumens: modelLumens,
        resolution: modelResolution,
      };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: modelName,
          brandId: modelBrandId,
          typeId: modelTypeId || null,
          ram: modelRam,
          processor: modelProcessor,
          storage: modelStorage,
          specs: JSON.stringify(specsObj),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al guardar modelo');

      setSuccess(`Modelo ${editingModel ? 'actualizado' : 'creado'} correctamente.`);
      setIsModelModalOpen(false);
      loadAllData();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteModel = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar este modelo?')) return;
    try {
      const res = await fetch(`/api/models/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error al eliminar');
      loadAllData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Filtered views
  const filteredTypes = types.filter((t) =>
    t.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredBrands = brands.filter((b) =>
    b.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredModels = models.filter((m) => {
    const matchesQuery =
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.brand?.name && m.brand.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (m.type?.name && m.type.name.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesBrand = !selectedBrandFilter || m.brandId === selectedBrandFilter;
    const matchesType = !selectedTypeFilter || m.typeId === selectedTypeFilter;
    return matchesQuery && matchesBrand && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Title Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-800">Catálogos de Equipos: Tipos, Marcas y Modelos</h1>
          <p className="text-xs text-slate-500">
            Asociación directa de Marcas y Modelos a Tipos de Equipos (Ej: Notebook HP, Laptop Lenovo, Monitor LG)
          </p>
        </div>

        {userRole !== 'LECTOR' && (
          <div className="flex items-center space-x-2">
            {activeTab === 'types' && (
              <button
                onClick={() => handleOpenTypeModal()}
                className="px-4 py-2 text-xs font-bold text-white bg-[#016098] hover:bg-[#014d7a] rounded-xl shadow-xs transition-colors flex items-center space-x-1.5"
              >
                <Plus className="w-4 h-4 text-[#39BABD]" />
                <span>Nuevo Tipo de Equipo</span>
              </button>
            )}

            {activeTab === 'brands' && (
              <button
                onClick={() => handleOpenBrandModal()}
                className="px-4 py-2 text-xs font-bold text-white bg-[#F7A517] hover:bg-[#d98f12] rounded-xl shadow-xs transition-colors flex items-center space-x-1.5"
              >
                <Plus className="w-4 h-4 text-white" />
                <span>Nueva Marca</span>
              </button>
            )}

            {activeTab === 'models' && (
              <button
                onClick={() => handleOpenModelModal()}
                className="px-4 py-2 text-xs font-bold text-white bg-[#39BABD] hover:bg-[#2fa4a7] rounded-xl shadow-xs transition-colors flex items-center space-x-1.5"
              >
                <Plus className="w-4 h-4 text-white" />
                <span>Nuevo Modelo</span>
              </button>
            )}
          </div>
        )}
      </div>

      {success && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-700 font-semibold flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{success}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 space-x-4">
        <button
          onClick={() => setActiveTab('types')}
          className={`py-2.5 px-4 font-bold text-xs border-b-2 transition-colors flex items-center space-x-2 ${
            activeTab === 'types'
              ? 'border-[#016098] text-[#016098]'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Tipos de Equipos ({types.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('brands')}
          className={`py-2.5 px-4 font-bold text-xs border-b-2 transition-colors flex items-center space-x-2 ${
            activeTab === 'brands'
              ? 'border-[#F7A517] text-[#F7A517]'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>Marcas ({brands.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('models')}
          className={`py-2.5 px-4 font-bold text-xs border-b-2 transition-colors flex items-center space-x-2 ${
            activeTab === 'models'
              ? 'border-[#39BABD] text-[#39BABD]'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>Modelos ({models.length})</span>
        </button>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Buscar en ${
              activeTab === 'types' ? 'tipos de equipo' : activeTab === 'brands' ? 'marcas' : 'modelos'
            }...`}
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#016098] outline-none"
          />
        </div>

        {activeTab === 'models' && (
          <div className="flex flex-col sm:flex-row items-center gap-2 w-full sm:w-auto">
            <select
              value={selectedTypeFilter}
              onChange={(e) => setSelectedTypeFilter(e.target.value)}
              className="w-full sm:w-48 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#016098] outline-none font-semibold text-slate-700"
            >
              <option value="">Todos los Tipos</option>
              {types.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>

            <select
              value={selectedBrandFilter}
              onChange={(e) => setSelectedBrandFilter(e.target.value)}
              className="w-full sm:w-48 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#39BABD] outline-none font-semibold text-slate-700"
            >
              <option value="">Todas las Marcas</option>
              {brands.map((b) => (
                <option key={b.id} value={b.id}>
                  Marca {b.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Content depending on Active Tab */}
      {loading ? (
        <div className="p-8 text-center text-slate-500 font-medium">Cargando catálogos de hardware...</div>
      ) : activeTab === 'types' ? (
        /* TYPES GRID WITH ASSOCIATED BRANDS */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTypes.map((type) => {
            let attrs: DynamicAttributeDef[] = [];
            try {
              attrs = JSON.parse(type.dynamic_attributes || '[]');
            } catch (e) {
              attrs = [];
            }

            let typeBrandIds: string[] = [];
            try {
              typeBrandIds = JSON.parse(type.associated_brands || '[]');
            } catch (e) {
              typeBrandIds = [];
            }

            // Combine explicitly linked brands and brands derived from models of this type
            const modelBrands = (type.models || []).map((m: any) => m.brand).filter(Boolean);
            const explicitBrands = brands.filter((b) => typeBrandIds.includes(b.id));

            const combinedBrandsMap = new Map<string, any>();
            [...explicitBrands, ...modelBrands].forEach((b) => combinedBrandsMap.set(b.id, b));
            const uniqueBrandsList = Array.from(combinedBrandsMap.values());

            return (
              <div
                key={type.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition-all"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 bg-[#016098]/10 rounded-xl">
                        <Layers className="w-5 h-5 text-[#016098]" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900 text-base">{type.name}</h3>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {type._count?.equipment || 0} equipos registrados
                        </span>
                      </div>
                    </div>

                    {userRole !== 'LECTOR' && (
                      <div className="flex space-x-1">
                        <button
                          onClick={() => handleOpenTypeModal(type)}
                          className="p-1.5 text-slate-500 hover:text-[#016098] hover:bg-slate-100 rounded-lg"
                          title="Editar tipo y marcas asociadas"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteType(type.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                          title="Eliminar tipo"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-500 mt-2">{type.description || 'Sin descripción'}</p>

                  {/* Associated Brands list */}
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <span className="text-[11px] font-bold text-[#F7A517] block mb-1.5 flex items-center space-x-1">
                      <Tag className="w-3 h-3" />
                      <span>Marcas Asociadas a este Tipo:</span>
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {uniqueBrandsList.length > 0 ? (
                        uniqueBrandsList.map((b) => (
                          <span
                            key={b.id}
                            className="px-2 py-0.5 bg-[#F7A517]/10 border border-[#F7A517]/30 rounded-md text-[10px] font-bold text-[#F7A517]"
                          >
                            {b.name}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-slate-400 italic">Sin marcas asociadas</span>
                      )}
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100">
                    <span className="text-[11px] font-bold text-slate-700 block mb-2">
                      Atributos Dinámicos Configurados:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {attrs.length > 0 ? (
                        attrs.map((a, idx) => (
                          <span
                            key={idx}
                            className="px-2.5 py-1 bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-medium text-slate-700"
                          >
                            {a.label} <span className="text-[#39BABD] font-mono">({a.type})</span>
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-slate-400 italic">Ninguno</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : activeTab === 'brands' ? (
        /* BRANDS GRID */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredBrands.map((brand) => (
            <div
              key={brand.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition-all"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <div className="p-2.5 bg-[#F7A517]/10 rounded-xl">
                      <Tag className="w-5 h-5 text-[#F7A517]" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">{brand.name}</h3>
                      <span className="text-[10px] text-slate-400 font-medium block">
                        {brand._count?.models || brand.models?.length || 0} modelos creados
                      </span>
                    </div>
                  </div>

                  {userRole !== 'LECTOR' && (
                    <div className="flex space-x-1">
                      <button
                        onClick={() => handleOpenBrandModal(brand)}
                        className="p-1.5 text-slate-500 hover:text-[#F7A517] hover:bg-slate-100 rounded-lg"
                        title="Editar marca"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteBrand(brand.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                        title="Eliminar marca"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Modelos Asociados:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {brand.models && brand.models.length > 0 ? (
                      brand.models.map((m: any) => (
                        <span
                          key={m.id}
                          className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[11px] font-semibold text-slate-700"
                        >
                          {m.name}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-slate-400 italic">Sin modelos registrados</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* MODELS TABLE WITH EQUIPMENT TYPE */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {filteredModels.length > 0 ? (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="py-3 px-4">Nombre del Modelo</th>
                  <th className="py-3 px-4">Marca Perteneciente</th>
                  <th className="py-3 px-4">Tipo de Equipo Asociado</th>
                  <th className="py-3 px-4">Especificaciones Configuradas del Modelo</th>
                  <th className="py-3 px-4 text-center">Equipos Registrados</th>
                  {userRole !== 'LECTOR' && <th className="py-3 px-4 text-right">Acciones</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredModels.map((m) => {
                  let parsedSpecs: any = {};
                  try {
                    parsedSpecs = JSON.parse(m.specs || '{}');
                  } catch (e) {}

                  const ramVal = m.ram || parsedSpecs.ram;
                  const cpuVal = m.processor || parsedSpecs.processor;
                  const storageVal = m.storage || parsedSpecs.storage;
                  const inkVal = parsedSpecs.ink_type;
                  const netVal = parsedSpecs.network_port;
                  const screenVal = parsedSpecs.screen_size;
                  const lumensVal = parsedSpecs.lumens;
                  const resVal = parsedSpecs.resolution;

                  const hasAnySpec = ramVal || cpuVal || storageVal || inkVal || netVal || screenVal || lumensVal || resVal;

                  return (
                    <tr key={m.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-bold text-slate-900">{m.name}</td>
                      <td className="py-3 px-4">
                        <span className="px-2.5 py-1 bg-[#F7A517]/10 text-[#F7A517] font-bold rounded-lg text-xs">
                          Marca {m.brand?.name}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {m.type?.name ? (
                          <span className="px-2.5 py-1 bg-[#016098]/10 text-[#016098] font-bold rounded-lg text-xs">
                            {m.type.name}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">Sin tipo asignado</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1">
                          {ramVal && (
                            <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[10px] font-mono text-slate-700">
                              RAM: <strong>{ramVal}</strong>
                            </span>
                          )}
                          {cpuVal && (
                            <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[10px] font-mono text-slate-700">
                              CPU: <strong>{cpuVal}</strong>
                            </span>
                          )}
                          {storageVal && (
                            <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[10px] font-mono text-slate-700">
                              Disco: <strong>{storageVal}</strong>
                            </span>
                          )}
                          {inkVal && (
                            <span className="px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-md text-[10px] font-semibold">
                              Tinta/Tóner: <strong>{inkVal}</strong>
                            </span>
                          )}
                          {netVal && (
                            <span className="px-2 py-0.5 bg-blue-50 border border-blue-200 text-blue-900 rounded-md text-[10px] font-semibold">
                              Red: <strong>{netVal}</strong>
                            </span>
                          )}
                          {screenVal && (
                            <span className="px-2 py-0.5 bg-indigo-50 border border-indigo-200 text-indigo-900 rounded-md text-[10px] font-semibold">
                              Pantalla: <strong>{screenVal}</strong>
                            </span>
                          )}
                          {lumensVal && (
                            <span className="px-2 py-0.5 bg-purple-50 border border-purple-200 text-purple-900 rounded-md text-[10px] font-semibold">
                              Brillo: <strong>{lumensVal}</strong>
                            </span>
                          )}
                          {resVal && (
                            <span className="px-2 py-0.5 bg-teal-50 border border-teal-200 text-teal-900 rounded-md text-[10px] font-semibold">
                              Res: <strong>{resVal}</strong>
                            </span>
                          )}
                          {!hasAnySpec && (
                            <span className="text-slate-400 italic text-[11px]">Sin especificaciones</span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center font-bold text-slate-800">
                        {m._count?.equipment || 0}
                      </td>
                      {userRole !== 'LECTOR' && (
                        <td className="py-3 px-4 text-right space-x-2">
                          <button
                            onClick={() => handleOpenModelModal(m)}
                            className="p-1.5 text-slate-500 hover:text-[#39BABD] hover:bg-slate-100 rounded-lg"
                            title="Editar modelo"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteModel(m.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                            title="Eliminar modelo"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="p-8 text-center text-slate-500">
              <p className="font-semibold">No se encontraron modelos para el filtro seleccionado.</p>
            </div>
          )}
        </div>
      )}

      {/* Equipment Type Modal with Brand Association */}
      {isTypeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="font-bold text-slate-800 text-lg">
              {editingType ? 'Editar Tipo de Equipo' : 'Nuevo Tipo de Equipo'}
            </h3>

            {error && <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl">{error}</div>}

            <form onSubmit={handleSaveType} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nombre del Tipo (Ej: Laptop, Monitor)</label>
                <input
                  type="text"
                  required
                  value={typeName}
                  onChange={(e) => setTypeName(e.target.value.toUpperCase())}
                  placeholder="Ej: LAPTOP NOTEBOOK"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#016098] outline-none font-bold uppercase"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Descripción</label>
                <input
                  type="text"
                  value={typeDescription}
                  onChange={(e) => setTypeDescription(e.target.value)}
                  placeholder="Ej: Equipos portátiles de alto rendimiento"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#016098] outline-none"
                />
              </div>

              {/* Brand Association Selector */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <label className="block text-xs font-bold text-slate-800 flex items-center space-x-1.5">
                  <Tag className="w-4 h-4 text-[#F7A517]" />
                  <span>Asociar a Marcas Creadas</span>
                </label>
                <p className="text-[11px] text-slate-500">
                  Seleccione las marcas pertenecientes o disponibles para este tipo de hardware:
                </p>

                <div className="flex flex-wrap gap-2 pt-1">
                  {brands.map((b) => {
                    const isSelected = selectedBrandIds.includes(b.id);
                    return (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => toggleBrandAssociation(b.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 border ${
                          isSelected
                            ? 'bg-[#F7A517] text-white border-[#F7A517] shadow-xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:border-[#F7A517]'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                        <span>{b.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dynamic Attributes Builder */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="font-bold text-xs text-slate-800 flex items-center space-x-1.5">
                  <Sliders className="w-4 h-4 text-[#39BABD]" />
                  <span>Configurador de Atributos Personalizados</span>
                </h4>

                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={attrKey}
                    onChange={(e) => setAttrKey(e.target.value)}
                    placeholder="Clave (ej: ram)"
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none font-mono"
                  />
                  <input
                    type="text"
                    value={attrLabel}
                    onChange={(e) => setAttrLabel(e.target.value)}
                    placeholder="Etiqueta (ej: RAM (GB))"
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none"
                  />
                  <select
                    value={attrType}
                    onChange={(e) => setAttrType(e.target.value as any)}
                    className="px-2 py-1.5 text-xs border border-slate-300 rounded-lg outline-none"
                  >
                    <option value="text">Texto</option>
                    <option value="number">Número</option>
                    <option value="boolean">Booleano</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleAddAttribute}
                  className="w-full py-1.5 bg-[#39BABD] text-white font-bold text-xs rounded-lg hover:bg-[#2fa4a7] transition-colors flex items-center justify-center space-x-1"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Agregar Atributo</span>
                </button>

                {/* List of current attributes */}
                <div className="space-y-1.5 pt-2">
                  {attributes.map((attr) => (
                    <div
                      key={attr.key}
                      className="flex items-center justify-between bg-white px-3 py-1.5 border border-slate-200 rounded-lg text-xs"
                    >
                      <span>
                        <strong>{attr.label}</strong> <span className="text-slate-400 font-mono">({attr.key})</span> -{' '}
                        <span className="text-[#016098] font-bold">{attr.type}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveAttribute(attr.key)}
                        className="text-rose-500 hover:text-rose-700 text-xs font-bold px-1.5"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsTypeModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-[#016098] hover:bg-[#014d7a] rounded-xl"
                >
                  Guardar Tipo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Brand Modal */}
      {isBrandModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="font-bold text-slate-800 text-lg">
              {editingBrand ? 'Editar Marca de Equipo' : 'Nueva Marca de Equipo'}
            </h3>

            {error && <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl">{error}</div>}

            <form onSubmit={handleSaveBrand} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nombre de la Marca</label>
                <input
                  type="text"
                  required
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value.toUpperCase())}
                  placeholder="Ej: LENOVO, HP, LG, VIEWSONIC, DELL, APPLE"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#F7A517] outline-none font-bold uppercase"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsBrandModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-[#F7A517] hover:bg-[#d98f12] rounded-xl"
                >
                  Guardar Marca
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Model Modal with EquipmentType Association */}
      {isModelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="font-bold text-slate-800 text-lg">
              {editingModel ? 'Editar Modelo' : 'Nuevo Modelo de Equipo'}
            </h3>

            {error && <div className="p-3 bg-rose-50 text-rose-700 text-xs rounded-xl">{error}</div>}

            <form onSubmit={handleSaveModel} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Marca Perteneciente</label>
                <select
                  required
                  value={modelBrandId}
                  onChange={(e) => setModelBrandId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#39BABD] outline-none font-bold text-slate-800"
                >
                  {brands.map((b) => (
                    <option key={b.id} value={b.id}>
                      Marca {b.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tipo de Equipo Asociado (Ej: Notebook, Monitor)
                </label>
                <select
                  value={modelTypeId}
                  onChange={(e) => setModelTypeId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#016098] outline-none font-bold text-[#016098]"
                >
                  <option value="">Sin Tipo Especificado (General)</option>
                  {types.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nombre del Modelo</label>
                <input
                  type="text"
                  required
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value.toUpperCase())}
                  placeholder="Ej: PROBOOK 450 G9, THINKPAD E14, 24MP400"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#39BABD] outline-none font-bold uppercase"
                />
              </div>

              {/* Dynamic Hardware Specs based on selected Equipment Type */}
              {(() => {
                const selectedType = types.find((t) => t.id === modelTypeId);
                const tName = selectedType?.name?.toUpperCase() || '';

                const isComputers =
                  tName.includes('NOTEBOOK') ||
                  tName.includes('ALL IN ONE') ||
                  tName.includes('PC ESCRITORIO') ||
                  tName.includes('LAPTOP') ||
                  tName.includes('DESKTOP');
                const isPrinter = tName.includes('IMPRESORA') || tName.includes('PRINTER');
                const isMonitor = tName.includes('MONITOR');
                const isProjector = tName.includes('PROYECTOR') || tName.includes('DATA');
                const isTablet = tName.includes('TABLET');

                if (!isComputers && !isPrinter && !isMonitor && !isProjector && !isTablet && modelTypeId) {
                  return null;
                }

                return (
                  <div className="p-3 bg-[#016098]/5 border border-[#016098]/20 rounded-xl space-y-2">
                    <span className="text-xs font-bold text-[#016098] flex items-center space-x-1.5">
                      <Sliders className="w-4 h-4 text-[#39BABD]" />
                      <span>Especificaciones Técnicas del Modelo ({selectedType?.name || 'General'})</span>
                    </span>

                    {/* ALL IN ONE, NOTEBOOK, PC ESCRITORIO */}
                    {(isComputers || !modelTypeId) && (
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">RAM</label>
                          <input
                            type="text"
                            value={modelRam}
                            onChange={(e) => setModelRam(e.target.value)}
                            placeholder="Ej: 16 GB"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Procesador</label>
                          <input
                            type="text"
                            value={modelProcessor}
                            onChange={(e) => setModelProcessor(e.target.value)}
                            placeholder="Ej: Intel Core i5"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Almacenamiento</label>
                          <input
                            type="text"
                            value={modelStorage}
                            onChange={(e) => setModelStorage(e.target.value)}
                            placeholder="Ej: 512 GB SSD"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                      </div>
                    )}

                    {/* IMPRESORA */}
                    {isPrinter && (
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Tipo de Tinta / Tóner</label>
                          <input
                            type="text"
                            value={modelInkType}
                            onChange={(e) => setModelInkType(e.target.value)}
                            placeholder="Ej: Tóner Láser HP 85A / Tinta Continuo"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Puerto de Red / Conectividad</label>
                          <input
                            type="text"
                            value={modelNetworkPort}
                            onChange={(e) => setModelNetworkPort(e.target.value)}
                            placeholder="Ej: Ethernet RJ45 + Wi-Fi / USB únicamente"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                      </div>
                    )}

                    {/* MONITOR DE ESCRITORIO */}
                    {isMonitor && (
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">Tamaño de Pantalla</label>
                        <input
                          type="text"
                          value={modelScreenSize}
                          onChange={(e) => setModelScreenSize(e.target.value)}
                          placeholder='Ej: 24 Pulgadas (Full HD) / 27"'
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                        />
                      </div>
                    )}

                    {/* PROYECTOR */}
                    {isProjector && (
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Lúmenes (Brillo)</label>
                          <input
                            type="text"
                            value={modelLumens}
                            onChange={(e) => setModelLumens(e.target.value)}
                            placeholder="Ej: 3600 Lúmenes ANSI"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Tamaño de Resolución</label>
                          <input
                            type="text"
                            value={modelResolution}
                            onChange={(e) => setModelResolution(e.target.value)}
                            placeholder="Ej: 1920x1080 Full HD / WXGA"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                      </div>
                    )}

                    {/* TABLET */}
                    {isTablet && (
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Almacenamiento</label>
                          <input
                            type="text"
                            value={modelStorage}
                            onChange={(e) => setModelStorage(e.target.value)}
                            placeholder="Ej: 64 GB / 128 GB"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Tamaño de Pantalla</label>
                          <input
                            type="text"
                            value={modelScreenSize}
                            onChange={(e) => setModelScreenSize(e.target.value)}
                            placeholder="Ej: 10.4 Pulgadas"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-1">Memoria RAM</label>
                          <input
                            type="text"
                            value={modelRam}
                            onChange={(e) => setModelRam(e.target.value)}
                            placeholder="Ej: 4 GB"
                            className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white font-semibold text-slate-800"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModelModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-[#39BABD] hover:bg-[#2fa4a7] rounded-xl"
                >
                  Guardar Modelo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
