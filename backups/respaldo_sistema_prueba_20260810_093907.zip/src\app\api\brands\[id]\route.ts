import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { id } = await params;
    const { name } = await req.json();

    if (!name || !name.trim()) {
      return NextResponse.json({ error: 'El nombre de la marca es obligatorio' }, { status: 400 });
    }

    const cleanName = name.trim().toUpperCase();

    const existing = await prisma.brand.findFirst({
      where: { name: cleanName, NOT: { id } },
    });

    if (existing) {
      return NextResponse.json({ error: `Ya existe otra marca con el nombre '${cleanName}'` }, { status: 400 });
    }

    const updated = await prisma.brand.update({
      where: { id },
      data: { name: cleanName },
      include: { models: true },
    });

    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: 'Error al actualizar marca' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { id } = await params;

    const equipmentCount = await prisma.equipment.count({
      where: { brandId: id },
    });

    if (equipmentCount > 0) {
      return NextResponse.json(
        { error: 'No se puede eliminar la marca porque tiene equipos vinculados' },
        { status: 400 }
      );
    }

    await prisma.brand.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Error al eliminar marca' }, { status: 500 });
  }
}
