import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { id } = await params;
    const { name, description, dynamic_attributes, associated_brands } = await req.json();

    const type = await prisma.equipmentType.findUnique({ where: { id } });
    if (!type) {
      return NextResponse.json({ error: 'Tipo de equipo no encontrado' }, { status: 404 });
    }

    const cleanName = name ? name.trim().toUpperCase() : type.name;

    if (cleanName !== type.name) {
      const existing = await prisma.equipmentType.findFirst({
        where: { name: cleanName, NOT: { id } },
      });
      if (existing) {
        return NextResponse.json({ error: `Ya existe otro tipo de equipo con el nombre '${cleanName}'` }, { status: 400 });
      }
    }

    const updated = await prisma.equipmentType.update({
      where: { id },
      data: {
        name: cleanName,
        description: description !== undefined ? description : type.description,
        dynamic_attributes: dynamic_attributes !== undefined
          ? (typeof dynamic_attributes === 'string' ? dynamic_attributes : JSON.stringify(dynamic_attributes))
          : type.dynamic_attributes,
        associated_brands: associated_brands !== undefined
          ? (typeof associated_brands === 'string' ? associated_brands : JSON.stringify(associated_brands))
          : type.associated_brands,
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    return NextResponse.json({ error: 'Error al actualizar tipo de equipo' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { id } = await params;

    const count = await prisma.equipment.count({ where: { typeId: id } });
    if (count > 0) {
      return NextResponse.json(
        { error: `No se puede eliminar porque existen ${count} equipos asociados a este tipo` },
        { status: 400 }
      );
    }

    await prisma.equipmentType.delete({ where: { id } });
    return NextResponse.json({ success: true, message: 'Tipo de equipo eliminado' });
  } catch (error) {
    return NextResponse.json({ error: 'Error al eliminar tipo de equipo' }, { status: 500 });
  }
}
