import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser, filterByBranchPermissions } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const query = searchParams.get('query') || '';
    const sectorId = searchParams.get('sectorId') || undefined;
    const branchId = searchParams.get('branchId') || undefined;
    const departmentId = searchParams.get('departmentId') || undefined;
    const typeId = searchParams.get('typeId') || undefined;
    const brandId = searchParams.get('brandId') || undefined;
    const status = searchParams.get('status') || undefined;

    const branchFilter = filterByBranchPermissions(sessionUser, branchId, sectorId);

    const equipment = await prisma.equipment.findMany({
      where: {
        ...branchFilter,
        ...(departmentId ? (departmentId === 'none' ? { departmentId: null } : { departmentId }) : {}),
        ...(typeId ? { typeId } : {}),
        ...(brandId ? { brandId } : {}),
        ...(status ? { status } : {}),
        OR: query
          ? [
              { asset_tag: { contains: query } },
              { serial_number: { contains: query } },
              { dynamic_values: { contains: query } },
              { brand: { name: { contains: query } } },
              { model: { name: { contains: query } } },
              {
                assignments: {
                  some: {
                    fecha_fin: null,
                    employee: {
                      full_name: { contains: query },
                    },
                  },
                },
              },
            ]
          : undefined,
      },
      include: {
        type: true,
        brand: true,
        model: true,
        branch: { include: { sector: true } },
        department: true,
        assignments: {
          where: { fecha_fin: null },
          include: {
            employee: {
              include: {
                branch: { include: { sector: true } },
                department: true,
              },
            },
            assignedByUser: {
              select: { id: true, name: true, email: true },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(equipment);
  } catch (error: any) {
    console.error('Error fetching equipment:', error);
    return NextResponse.json({ error: 'Error al consultar inventario' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const {
      asset_tag,
      serial_number,
      typeId,
      brandId,
      modelId,
      branchId,
      departmentId,
      dynamic_values,
      status,
      assignedEmployeeId,
      assignmentNotes,
    } = await req.json();

    if (!asset_tag || !serial_number || !typeId || !branchId) {
      return NextResponse.json(
        { error: 'Asset Tag, Serie, Tipo y Sucursal son requeridos' },
        { status: 400 }
      );
    }

    if (status === 'asignado' && !assignedEmployeeId) {
      return NextResponse.json(
        { error: 'Debe seleccionar un funcionario para registrar un equipo con estado Asignado' },
        { status: 400 }
      );
    }

    const existingTag = await prisma.equipment.findUnique({
      where: { asset_tag: asset_tag.trim().toUpperCase() },
    });
    if (existingTag) {
      return NextResponse.json({ error: `El código Asset Tag '${asset_tag}' ya existe` }, { status: 400 });
    }

    const existingSerial = await prisma.equipment.findUnique({
      where: { serial_number: serial_number.trim().toUpperCase() },
    });
    if (existingSerial) {
      return NextResponse.json({ error: `El número de serie '${serial_number}' ya está registrado` }, { status: 400 });
    }

    let finalBranchId = branchId;
    let finalDeptId = departmentId ? departmentId : null;

    if (status === 'asignado' && assignedEmployeeId) {
      const assignedEmp = await prisma.employee.findUnique({
        where: { id: assignedEmployeeId },
      });
      if (assignedEmp) {
        finalBranchId = assignedEmp.branchId;
        finalDeptId = assignedEmp.departmentId || null;
      }
    }

    const equipment = await prisma.equipment.create({
      data: {
        asset_tag: asset_tag.trim().toUpperCase(),
        serial_number: serial_number.trim().toUpperCase(),
        typeId,
        brandId: brandId || null,
        modelId: modelId || null,
        branchId: finalBranchId,
        departmentId: finalDeptId,
        dynamic_values: typeof dynamic_values === 'string' ? dynamic_values : JSON.stringify(dynamic_values || {}),
        status: status || 'disponible',
      },
      include: {
        type: true,
        brand: true,
        model: true,
        branch: { include: { sector: true } },
        department: true,
      },
    });

    if (status === 'asignado' && assignedEmployeeId) {
      await prisma.equipmentAssignment.create({
        data: {
          equipmentId: equipment.id,
          employeeId: assignedEmployeeId,
          assignedByUserId: sessionUser.id,
          notes: assignmentNotes || 'Asignación al crear equipo en inventario',
        },
      });
    }

    const result = await prisma.equipment.findUnique({
      where: { id: equipment.id },
      include: {
        type: true,
        brand: true,
        model: true,
        branch: { include: { sector: true } },
        department: true,
        assignments: {
          where: { fecha_fin: null },
          include: { employee: true },
        },
      },
    });

    return NextResponse.json(result, { status: 201 });
  } catch (error: any) {
    console.error('Error creating equipment:', error);
    return NextResponse.json({ error: 'Error al registrar equipo en inventario: ' + error.message }, { status: 500 });
  }
}
