import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const equipmentId = searchParams.get('equipmentId');
    const employeeId = searchParams.get('employeeId');

    const assignments = await prisma.equipmentAssignment.findMany({
      where: {
        ...(equipmentId ? { equipmentId } : {}),
        ...(employeeId ? { employeeId } : {}),
      },
      include: {
        equipment: {
          include: {
            type: true,
            branch: true,
            department: true,
          },
        },
        employee: {
          include: {
            branch: true,
            department: true,
          },
        },
        assignedByUser: {
          select: { id: true, name: true, email: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(assignments);
  } catch (error) {
    return NextResponse.json({ error: 'Error al consultar historial de asignaciones' }, { status: 500 });
  }
}

// POST: Assign Equipment to Employee & Sync Equipment Branch/Department to Employee
export async function POST(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { equipmentId, employeeId, notes } = await req.json();

    if (!equipmentId || !employeeId) {
      return NextResponse.json({ error: 'Se requiere id de equipo y de funcionario' }, { status: 400 });
    }

    const equipment = await prisma.equipment.findUnique({
      where: { id: equipmentId },
    });

    if (!equipment) {
      return NextResponse.json({ error: 'Equipo no encontrado' }, { status: 404 });
    }

    if (equipment.status !== 'disponible') {
      return NextResponse.json(
        { error: `El equipo con Asset Tag ${equipment.asset_tag} no está disponible (Estado actual: '${equipment.status}')` },
        { status: 400 }
      );
    }

    const employee = await prisma.employee.findUnique({
      where: { id: employeeId },
    });

    if (!employee || employee.status !== 'ACTIVO') {
      return NextResponse.json({ error: 'Funcionario no encontrado o inactivo' }, { status: 400 });
    }

    // Execute assignment and update equipment location parameters (branchId & departmentId) to match Employee
    const [assignment, updatedEquipment] = await prisma.$transaction([
      prisma.equipmentAssignment.create({
        data: {
          equipmentId,
          employeeId,
          fecha_inicio: new Date(),
          assignedByUserId: sessionUser.id,
          notes: notes ? notes.trim() : null,
        },
        include: {
          equipment: { include: { type: true } },
          employee: true,
          assignedByUser: { select: { name: true, email: true } },
        },
      }),
      prisma.equipment.update({
        where: { id: equipmentId },
        data: {
          status: 'asignado',
          branchId: employee.branchId,
          departmentId: employee.departmentId || null,
        },
      }),
    ]);

    return NextResponse.json({ success: true, assignment, equipment: updatedEquipment }, { status: 201 });
  } catch (error: any) {
    console.error('Error assigning equipment:', error);
    return NextResponse.json({ error: 'Error al procesar asignación: ' + error.message }, { status: 500 });
  }
}

// PUT: Unassign Equipment (Return to disponible)
export async function PUT(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { equipmentId, notes } = await req.json();

    if (!equipmentId) {
      return NextResponse.json({ error: 'Se requiere id de equipo' }, { status: 400 });
    }

    const activeAssignment = await prisma.equipmentAssignment.findFirst({
      where: { equipmentId, fecha_fin: null },
    });

    if (!activeAssignment) {
      return NextResponse.json({ error: 'No hay ninguna asignación activa para este equipo' }, { status: 400 });
    }

    const [closedAssignment, updatedEquipment] = await prisma.$transaction([
      prisma.equipmentAssignment.update({
        where: { id: activeAssignment.id },
        data: {
          fecha_fin: new Date(),
          notes: notes ? (activeAssignment.notes ? `${activeAssignment.notes} | Desasignación: ${notes}` : notes) : activeAssignment.notes,
        },
      }),
      prisma.equipment.update({
        where: { id: equipmentId },
        data: { status: 'disponible' },
      }),
    ]);

    return NextResponse.json({ success: true, message: 'Equipo desasignado exitosamente', equipment: updatedEquipment });
  } catch (error: any) {
    console.error('Error unassigning equipment:', error);
    return NextResponse.json({ error: 'Error al desasignar equipo' }, { status: 500 });
  }
}
