import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const types = await prisma.equipmentType.findMany({
      include: {
        models: { include: { brand: true } },
        _count: {
          select: { equipment: true, models: true },
        },
      },
      orderBy: { name: 'asc' },
    });

    return NextResponse.json(types);
  } catch (error) {
    return NextResponse.json({ error: 'Error al consultar tipos de equipo' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { name, description, dynamic_attributes, associated_brands } = await req.json();

    if (!name || !name.trim()) {
      return NextResponse.json({ error: 'El nombre del tipo de equipo es obligatorio' }, { status: 400 });
    }

    const cleanName = name.trim().toUpperCase();

    const existing = await prisma.equipmentType.findFirst({
      where: { name: cleanName },
    });

    if (existing) {
      return NextResponse.json({ error: `El tipo de equipo '${cleanName}' ya existe` }, { status: 400 });
    }

    const type = await prisma.equipmentType.create({
      data: {
        name: cleanName,
        description: description ? description.trim() : null,
        dynamic_attributes: typeof dynamic_attributes === 'string'
          ? dynamic_attributes
          : JSON.stringify(dynamic_attributes || []),
        associated_brands: typeof associated_brands === 'string'
          ? associated_brands
          : JSON.stringify(associated_brands || []),
      },
    });

    return NextResponse.json(type, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: 'Error al crear tipo de equipo' }, { status: 500 });
  }
}
