import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSessionUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const brandId = searchParams.get('brandId') || undefined;
    const typeId = searchParams.get('typeId') || undefined;

    const models = await prisma.equipmentModel.findMany({
      where: {
        ...(brandId ? { brandId } : {}),
        ...(typeId ? { typeId } : {}),
      },
      include: {
        brand: true,
        type: true,
        _count: { select: { equipment: true } },
      },
      orderBy: { name: 'asc' },
    });

    return NextResponse.json(models);
  } catch (error) {
    return NextResponse.json({ error: 'Error al obtener modelos' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser || sessionUser.role === 'LECTOR') {
      return NextResponse.json({ error: 'Permisos insuficientes' }, { status: 403 });
    }

    const { name, brandId, typeId, ram, processor, storage, specs } = await req.json();

    if (!name || !name.trim() || !brandId) {
      return NextResponse.json({ error: 'Nombre del modelo y marca son obligatorios' }, { status: 400 });
    }

    const cleanName = name.trim().toUpperCase();

    // Block any duplicate model name for this brand or globally
    const existingForBrand = await prisma.equipmentModel.findFirst({
      where: {
        name: cleanName,
        brandId,
      },
    });

    if (existingForBrand) {
      return NextResponse.json({ error: `El modelo '${cleanName}' ya se encuentra registrado para esta marca` }, { status: 400 });
    }

    const existingGlobal = await prisma.equipmentModel.findFirst({
      where: {
        name: cleanName,
      },
    });

    if (existingGlobal) {
      return NextResponse.json({ error: `No se permiten nombres de modelos duplicados. El modelo '${cleanName}' ya existe` }, { status: 400 });
    }

    const model = await prisma.equipmentModel.create({
      data: {
        name: cleanName,
        brandId,
        typeId: typeId || null,
        ram: ram?.trim() || null,
        processor: processor?.trim() || null,
        storage: storage?.trim() || null,
        specs: specs ? (typeof specs === 'string' ? specs : JSON.stringify(specs)) : null,
      },
      include: { brand: true, type: true },
    });

    return NextResponse.json(model, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: 'Error al crear modelo: ' + error.message }, { status: 500 });
  }
}
