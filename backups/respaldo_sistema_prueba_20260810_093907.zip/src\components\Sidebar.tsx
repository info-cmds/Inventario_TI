'use client';

import React from 'react';
import {
  LayoutDashboard,
  Laptop,
  History,
  Users,
  Building,
  Layers,
  UserCheck,
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  userRole: string;
}

export default function Sidebar({ currentTab, onTabChange, userRole }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'equipment', label: 'Inventario de Equipos', icon: Laptop },
    { id: 'assignments', label: 'Asignaciones y Historial', icon: History },
    { id: 'employees', label: 'Funcionarios', icon: Users },
    { id: 'branches', label: 'Estructura Org.', icon: Building },
    { id: 'equipment-types', label: 'Tipos y Atributos', icon: Layers },
    ...(userRole === 'SUPERADMIN' ? [{ id: 'users', label: 'Gestión de Usuarios', icon: UserCheck }] : []),
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 shadow-xs flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      <div className="p-4 border-b border-slate-100 flex flex-col items-center justify-center space-y-2 bg-slate-50/50">
        <img src="/logo-cmds.png" alt="CMDS Antofagasta" className="h-12 w-auto object-contain" />
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Menú Principal</span>
      </div>

      <nav className="p-3 space-y-1 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all duration-150 ${
                isActive
                  ? 'bg-[#016098] text-white shadow-xs font-semibold'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-[#016098]'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-[#39BABD]' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Brand Footer Info */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50 text-xs text-slate-500 space-y-1">
        <div className="font-bold text-slate-800">CMDS Inventario v1.0.0</div>
        <div className="text-[11px] text-slate-600 font-semibold">Empresa CMDS</div>
        <div className="text-[10px] text-[#016098] font-bold">Desarrollado por Informática CMDS</div>
      </div>
    </aside>
  );
}
